package com.ips.tpsi.pokemonwebapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest

class PokemonwebappApplicationTests {

	@Test
	void contextLoads() {
	}

}
